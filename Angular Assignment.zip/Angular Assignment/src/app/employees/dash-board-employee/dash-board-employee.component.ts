import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dash-board-employee',
  templateUrl: './dash-board-employee.component.html',
  styleUrls: ['./dash-board-employee.component.css']
})
export class DashBoardEmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
