export class Employee {
    id: number;
    name: string;
    phoneNumber: number;
    department: string;
    salary: number;

}